export async function onRequest(context) {
  const { request, params } = context;
  const url = new URL(request.url);

  // Get everything after /api/
  const apiPath = params.path.join("/");

  // Build target URL for Replit API
  const targetUrl = `https://01d026c7-4f7c-484e-86da-899426f53456-00-3rb8i4u7xysjq.kirk.replit.dev/api/${apiPath}`;

  // Forward request to Replit
  const response = await fetch(targetUrl, {
    method: request.method,
    headers: request.headers,
    body:
      request.method !== "GET" && request.method !== "HEAD"
        ? await request.text()
        : undefined,
  });

  // Return the proxied response
  return new Response(await response.text(), {
    status: response.status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*", // optional for CORS
    },
  });
}
